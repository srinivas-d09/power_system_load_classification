import pandas as pd
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, HistGradientBoostingClassifier, VotingClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
import joblib, json, os

DATA = "data/load_data.csv"
df = pd.read_csv(DATA)
df["Date_Time"] = pd.to_datetime(df["Date_Time"], dayfirst=True, errors="coerce")
df = df.dropna(subset=["Date_Time", "Load_Type"]).sort_values("Date_Time")
# Time-derived features support recurring daily/weekly/monthly patterns.
dt = df["Date_Time"]
df["hour"] = dt.dt.hour + dt.dt.minute / 60
df["day"] = dt.dt.day
df["weekday"] = dt.dt.dayofweek
df["month"] = dt.dt.month
df["dayofyear"] = dt.dt.dayofyear
df["hour_sin"] = __import__("numpy").sin(2 * __import__("numpy").pi * df["hour"] / 24)
df["hour_cos"] = __import__("numpy").cos(2 * __import__("numpy").pi * df["hour"] / 24)
df["weekday_sin"] = __import__("numpy").sin(2 * __import__("numpy").pi * df["weekday"] / 7)
df["weekday_cos"] = __import__("numpy").cos(2 * __import__("numpy").pi * df["weekday"] / 7)
target = "Load_Type"
drop = ["Date_Time", target]
X = df.drop(columns=drop)
y = df[target]
# Required chronological evaluation: hold out the latest calendar month.
last_month = df["Date_Time"].dt.to_period("M").max()
test_mask = df["Date_Time"].dt.to_period("M") == last_month
X_train, X_test = X.loc[~test_mask], X.loc[test_mask]
y_train, y_test = y.loc[~test_mask], y.loc[test_mask]
model = ExtraTreesClassifier(n_estimators=500, min_samples_leaf=1, class_weight="balanced", random_state=42, n_jobs=-1)
model.fit(X_train, y_train)
pred = model.predict(X_test)
metrics = {
 "test_month": str(last_month),
 "train_rows": int(len(X_train)),
 "test_rows": int(len(X_test)),
 "accuracy": float(accuracy_score(y_test, pred)),
 "classification_report": classification_report(y_test, pred, output_dict=True, zero_division=0),
 "confusion_matrix_labels": list(model.classes_),
 "confusion_matrix": confusion_matrix(y_test, pred, labels=model.classes_).tolist()
}
print("Held-out month:", last_month)
print("Accuracy:", round(metrics["accuracy"], 4))
print(classification_report(y_test, pred, zero_division=0))
print("Confusion matrix (labels order):", list(model.classes_))
print(confusion_matrix(y_test, pred, labels=model.classes_))
os.makedirs("artifacts", exist_ok=True)
joblib.dump({"model": model, "feature_columns": list(X.columns), "test_month": str(last_month)}, "artifacts/load_type_model.joblib")
with open("artifacts/metrics.json", "w") as f: json.dump(metrics, f, indent=2)
pd.DataFrame({"Date_Time": df.loc[test_mask, "Date_Time"], "Actual_Load_Type": y_test, "Predicted_Load_Type": pred}).to_csv("artifacts/last_month_predictions.csv", index=False)
