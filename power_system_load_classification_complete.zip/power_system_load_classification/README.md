# Power System Load Type Classification

## 1. Problem statement
Build a supervised classification model to predict `Load_Type`:
- `Light_Load`
- `Medium_Load`
- `Maximum_Load`

This project follows the assignment's required chronological evaluation: **the latest calendar month is held out as the test set**. Earlier observations are used for training.

## 2. Project structure
```text
power_system_load_classification/
├── app.py                         # interactive Streamlit dashboard
├── train_model.py                 # end-to-end preprocessing, training, evaluation
├── load_type_classification.ipynb # notebook workflow
├── requirements.txt
├── README.md
├── data/
│   └── README.txt                 # put load_data.csv here
├── figures/                       # generated charts
└── artifacts/                     # trained model, metrics, predictions
```

## 3. Setup (Windows PowerShell)
Open a terminal in this project folder:
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```
If PowerShell blocks activation, use `.\.venv\Scripts\python.exe -m pip install -r requirements.txt` and run commands with `.\.venv\Scripts\python.exe`.

## 4. Add the dataset
Copy the CSV provided with your assignment to `data/load_data.csv`. The CSV must include a date/time column, predictor columns, and `Load_Type`. The script accepts common variations of names such as `Date`, `Date_Time`, `Usage_kWh`, `CO2`, and `NSM`.

The uploaded materials did not include the actual CSV. Consequently, no accuracy or chart results are claimed until the real dataset is added and the code is run.

## 5. Train, evaluate, and create 10 visualizations
```powershell
python train_model.py
```
Or provide a different path:
```powershell
python train_model.py --data "C:\path\to\load_data.csv"
```
The script saves:
- `figures/01_class_distribution.png`
- `figures/02_usage_over_time.png` (when Usage_kWh exists)
- `figures/03_correlation_heatmap.png`
- `figures/04_usage_by_class.png` (when Usage_kWh exists)
- `figures/05_hourly_usage.png` (when Usage_kWh exists)
- `figures/06_feature_importance.png`
- `figures/07_confusion_matrix.png`
- `figures/08_confusion_normalized.png`
- `figures/09_classification_metrics.png`
- `figures/10_test_predictions_timeline.png`
- `artifacts/load_type_model.joblib`
- `artifacts/metrics.json`
- `artifacts/last_month_predictions.csv`

Metrics include accuracy, balanced accuracy, macro precision/recall/F1, and per-class precision/recall/F1. Confusion matrices reveal which load categories are being confused.

## 6. Open the interactive dashboard
```powershell
streamlit run app.py
```
The dashboard lets you inspect a dataset, see class balance/correlation, review model metrics and generated charts, and enter a numeric record for prediction after training.

## 7. Open the Jupyter notebook
```powershell
jupyter notebook load_type_classification.ipynb
```
Run all cells from top to bottom after placing the dataset in `data/load_data.csv`.

## 8. Problem-solving decisions (explain these in your viva)
1. **Why chronological split?** Random splitting can put later records in training and earlier records in testing. Holding out the latest month better simulates predicting future load types.
2. **Why cyclical time features?** Hour 23 is near hour 0, but ordinary numeric values make them look far apart. Sine/cosine features represent this cycle.
3. **Why Extra Trees?** It handles nonlinear relationships and mixed-scale numeric features with limited scaling requirements. It also provides feature importance for interpretation.
4. **Why more than accuracy?** Class imbalance can hide poor performance on a minority class. Macro F1 and per-class recall show performance for each class.
5. **How is missing data handled?** Invalid date/target rows are removed; numeric missing values are filled using medians calculated on training data only, avoiding leakage from the test month.
6. **What is leakage and how is it reduced?** Test-month rows are excluded from fitting. Imputation statistics come from training rows. Do not use future-derived values as features in a real deployment.
7. **What would improve the project?** Compare several rolling-origin monthly splits, tune parameters only inside training data, inspect errors by hour/day, calibrate probabilities, and monitor performance as new months arrive.

## 9. Common troubleshooting
- `FileNotFoundError`: ensure `data/load_data.csv` exists or pass `--data`.
- Missing target/date error: inspect CSV headers and confirm the target column is named `Load_Type`.
- Notebook starts in the wrong directory: change the notebook working directory to this project root.
- Slow first run: the 500-tree ensemble may take a little time; wait for completion.

## 10. Submission checklist
- [ ] Add the real assignment CSV.
- [ ] Install requirements.
- [ ] Run all notebook cells.
- [ ] Run `python train_model.py` and confirm artifacts/figures are created.
- [ ] Open `streamlit run app.py` and test dashboard.
- [ ] Include actual generated charts and actual measured metrics in your report; never invent results.
