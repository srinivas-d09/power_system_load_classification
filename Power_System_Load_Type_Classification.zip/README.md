# Power System Load Type Classification: Machine Learning Pipeline & Operational Analysis

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Scikit-Learn](https://img.shields.io/badge/scikit--learn-1.3+-orange.svg)](https://scikit-learn.org/)
[![Status: Complete](https://img.shields.io/badge/Status-Complete-brightgreen.svg)]()

> An end-to-end industrial data science project demonstrating advanced problem-solving, electrical domain engineering, strict chronological holdout validation, and multi-model benchmarking to classify power system load regimes (`Light_Load`, `Medium_Load`, `Maximum_Load`).

---

## 1. Executive Summary & Problem Framing

Modern power distribution networks and industrial smart grids require real-time demand-side management (DSM) to balance fluctuating load profiles with generation resources. Accurately classifying industrial load regimes into **Light Load**, **Medium Load**, and **Maximum Load** enables utility operators and energy managers to:
- **Prevent Distribution Transformer Overloading:** Automate peak-shaving dispatch and shed non-critical loads during high-stress periods.
- **Optimize Time-of-Use (TOU) Tariff Scheduling:** Shift flexible manufacturing operations into low-tariff, off-peak windows.
- **Regulate Power Factor & Mitigate Penalties:** Track reactive power displacement and capacitor bank switching in real time.
- **Accurately Account for Carbon Emissions:** Attribute grid CO₂ footprints to specific high-intensity manufacturing intervals.

### Technical Objective
Develop a high-performance machine learning classification pipeline on continuous 15-minute telemetry (35,040 readings across all of 2018) to predict `Load_Type`.

### Validation Integrity (Preventing Temporal Leakage)
Unlike standard tabular datasets where random cross-validation or shuffled train-test splits are applied, **power system time series suffer from severe autocorrelation leakage** if shuffled. This project strictly enforces an out-of-sample **chronological holdout**:
- **Training Set (Months 1–11):** January 1, 2018 – November 30, 2018 (**32,064 intervals** / 91.5%)
- **Test Set (Holdout Month 12):** December 1, 2018 – December 31, 2018 (**2,977 intervals** / 8.5%)

The holdout test month is strictly isolated and never seen during feature scaling, preprocessing, or model fitting.

---

## 2. Key Results & Benchmark Scorecard

| Model Architecture | Paradigm | Train Acc | Holdout Acc (Dec 2018) | Macro F1 | Weighted F1 | Macro Recall | Inference Latency |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Extra Trees Classifier (Champion)** | Extremely Randomized Trees | 1.0000 | **94.76%** | **0.9413** | **0.9481** | **95.35%** | **2.1 ms** |
| **HistGradientBoosting** | Gradient Boosted Trees | 0.9982 | **93.89%** | **0.9312** | **0.9392** | 94.21% | 3.4 ms |
| **Random Forest** | Bagging Ensemble | 0.9998 | **93.52%** | **0.9275** | **0.9358** | 93.85% | 4.8 ms |
| **Decision Tree (max_depth=12)** | Single Tree (Pruned) | 0.9620 | **89.42%** | **0.8821** | **0.8940** | 89.15% | 0.8 ms |
| **Logistic Regression (StandardScaler)** | Linear Baseline | 0.7410 | **72.15%** | **0.7104** | **0.7230** | 71.80% | 0.4 ms |

### Champion Model Per-Class Breakdown (December Holdout)

```
              precision    recall  f1-score   support

  Light_Load     0.9826    0.9364    0.9589      1745
Maximum_Load     0.9080    0.9527    0.9298       528
 Medium_Load     0.9012    0.9716    0.9351       704

    accuracy                         0.9476      2977
   macro avg     0.9306    0.9535    0.9413      2977
weighted avg     0.9501    0.9476    0.9481      2977
```

---

## 3. Repository Architecture & Directory Structure

```
├── README.md                              # Comprehensive project documentation
├── requirements.txt                       # Python package dependencies
├── load_type_classification.ipynb         # Master end-to-end Jupyter Notebook
├── train_model.py                         # Production CLI model training script
├── train_with_visualizations.py           # Full visualization & diagnostic figure generator
├── data/
│   └── load_data.csv                      # Telemetry dataset (35,040 rows, 15-min intervals)
├── figures/                               # 10 publication-quality diagnostic PNG charts
│   ├── 01_class_distribution.png         # Figure 1: Sample counts & class imbalance
│   ├── 02_time_series.png                # Figure 2: 15-min and daily mean energy trends
│   ├── 03_feature_distributions.png      # Figure 3: Empirical KDE distributions by class
│   ├── 04_correlation_heatmap.png        # Figure 4: Inter-feature Pearson correlation matrix
│   ├── 05_hourly_patterns.png            # Figure 5: Diurnal & day-of-week heatmaps
│   ├── 06_weekday_patterns.png           # Figure 6: Electrical parameter boxplots
│   ├── 07_feature_importance.png         # Figure 7: Extra Trees Gini importance ranking
│   ├── 08_confusion_matrix.png           # Figure 8: Holdout confusion matrix (counts)
│   ├── 09_per_class_metrics.png          # Figure 9: Per-class Precision / Recall / F1
│   └── 10_confusion_matrix_normalized.png# Figure 10: Row-normalized recall confusion matrix
└── artifacts/                             # Serialized models and evaluation outputs
    ├── load_type_model.joblib             # Trained champion model & feature metadata
    ├── metrics.json                       # Machine-readable test metrics
    └── last_month_predictions.csv         # December holdout row-level predictions
```

---

## 4. Problem-Solving Methodology

### Phase 1: Data Hygiene & Physical Bounds Auditing
- Verified timestamp continuity (monotonic 15-minute intervals spanning 365 days).
- Checked for missing values, zero duplicates, and validated physical bounds ($0\% \le \text{Power Factor} \le 100\%$, positive active energy).

### Phase 2: Domain-Driven Feature Engineering
1. **Cyclical Temporal Encodings:**
   Standard numerical time attributes create an artificial discontinuity between 23:45 and 00:00 ($|23.75 - 0.0| = 23.75$). We map timestamps onto continuous unit circles:
   $$\text{hour}_{\sin} = \sin\left(\frac{2\pi \cdot \text{hour}}{24}\right), \quad \text{hour}_{\cos} = \cos\left(\frac{2\pi \cdot \text{hour}}{24}\right)$$
   $$\text{weekday}_{\sin} = \sin\left(\frac{2\pi \cdot \text{weekday}}{7}\right), \quad \text{weekday}_{\cos} = \cos\left(\frac{2\pi \cdot \text{weekday}}{7}\right)$$
2. **Calendar Attributes:** Extracted `hour`, `day`, `weekday`, `month`, `dayofyear`, and `is_weekend`.
3. **Electrical Domain Formulations:** Apparent Power $S = \sqrt{P^2 + Q_{\text{lag}}^2}$ and Reactive Power Ratio ($Q / P$).

### Phase 3: Exploratory Data Analysis Insights
- **Class Imbalance:** Light Load constitutes ~50.5% of samples, Medium Load ~27.7%, and Maximum Load ~21.8%.
- **Multicollinearity:** $\text{CO}_2$ emissions are linearly derived from active power ($r = 0.99$), and `NSM` strictly mirrors fractional hours ($r = 1.00$). Tree ensembles naturally handle this without variance inflation.
- **Power Factor Phase Shifts:** Industrial capacitor banks maintain leading power factor during off-peak night shifts (`Leading_Current_Reactive_Power_kVarh` active), while heavy motor inductive loads induce lagging power factor during production shifts.

### Phase 4: Granular Error Diagnosis
Analyzing the 156 misclassified holdout intervals revealed:
- **Shift Transition Ambiguity:** Over 78% of errors occur at exact shift changeover boundaries (07:45–08:15 and 16:45–17:15) when machinery ramps up or down.
- **Mitigation:** In deployment, applying a 3-step rolling majority filter (45-minute window) eliminates single-sample transient noise.

---

## 5. Quickstart & Reproduction

### Prerequisites
- Python 3.10+
- Virtual environment tool (`venv` or `conda`)

### Installation
```bash
# 1. Clone repository or extract submission ZIP
cd power_system_load_type_classification

# 2. Create and activate virtual environment
python3 -m venv .venv
source .venv/bin/activate       # On Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt
```

### Running the Complete Pipeline
```bash
# Execute training and generate all 10 diagnostic figures
python3 train_with_visualizations.py

# Or run the streamlined CLI trainer
python3 train_model.py
```

### Interactive Notebook
Launch Jupyter Notebook to interact with all analytical commentary, code cells, and inline charts:
```bash
jupyter notebook load_type_classification.ipynb
```

---

## 6. Grid Operations & Production Roadmap

1. **SCADA Telemetry Integration:** Model executes inference in **2.1 ms**, well within the 900-second 15-minute window.
2. **Drift Monitoring:** Population Stability Index (PSI) and Kolmogorov-Smirnov (KS) tests run continuously on incoming telemetry to alert engineers if manufacturing schedules alter.
3. **Automated Demand Response:** Automatically dispatches alerts when `Maximum_Load` is predicted during grid peak-tariff periods, enabling proactive peak shaving.
