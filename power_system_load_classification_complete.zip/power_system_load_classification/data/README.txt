Place the assignment dataset CSV here and name it load_data.csv.
Required columns: a date/time column, numeric power/energy features, and Load_Type.
The training script accepts common column-name variants and can use another path:
python train_model.py --data "path/to/your.csv"
No dataset was included in the uploaded assignment files, so metrics are not fabricated.
